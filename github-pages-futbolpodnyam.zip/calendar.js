const calendar = document.querySelector('[data-calendar]');

if (calendar) {
  const groups = [...calendar.querySelectorAll('[data-date]')];
  const buttons = [...calendar.querySelectorAll('[data-range]')];
  const options = calendar.querySelector('.day-filters');
  const empty = calendar.querySelector('.empty-calendar');
  const heroDate = document.querySelector('[data-today]');
  const dateFormat = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Moscow', year: 'numeric', month: '2-digit', day: '2-digit',
  });
  const heroFormat = new Intl.DateTimeFormat('ru-RU', {
    timeZone: 'Europe/Moscow', weekday: 'long', day: 'numeric', month: 'long',
  });
  const ranges = {
    today: 'На сегодня пока нет проверенных матчей в подборке.',
    tomorrow: 'На завтра пока нет проверенных матчей в подборке.',
    upcoming: 'Ближайшие матчи ещё не добавлены в подборку.',
  };

  function moscowDate() {
    const parts = Object.fromEntries(dateFormat.formatToParts(new Date()).map(({type, value}) => [type, value]));
    return [parts.year, parts.month, parts.day].join('-');
  }

  function render(range, today) {
    if (heroDate) {
      const text = heroFormat.format(new Date(today + 'T12:00:00Z'));
      heroDate.dateTime = today;
      heroDate.textContent = text.charAt(0).toUpperCase() + text.slice(1);
    }
    const nextDay = new Date(today + 'T00:00:00Z');
    nextDay.setUTCDate(nextDay.getUTCDate() + 1);
    const tomorrow = nextDay.toISOString().slice(0, 10);
    let visible = 0;
    for (const group of groups) {
      const date = group.dataset.date;
      const show = range === 'upcoming' ? date >= today : date === (range === 'today' ? today : tomorrow);
      group.hidden = !show;
      visible += Number(show);
    }
    for (const button of buttons) {
      button.setAttribute('aria-pressed', String(button.dataset.range === range));
    }
    empty.hidden = visible > 0;
    empty.textContent = visible ? '' : ranges[range];
  }

  let currentRange = calendar.dataset.defaultRange;
  let currentDate = moscowDate();
  options.hidden = false;
  options.addEventListener('click', (event) => {
    const button = event.target.closest('[data-range]');
    if (button) {
      currentRange = button.dataset.range;
      render(currentRange, currentDate = moscowDate());
    }
  });
  window.addEventListener('pageshow', () => render(currentRange, currentDate = moscowDate()));
  window.setInterval(() => {
    const today = moscowDate();
    if (today !== currentDate) {
      currentDate = today;
      render(currentRange, currentDate);
    }
  }, 60000);
  render(currentRange, currentDate);
}
